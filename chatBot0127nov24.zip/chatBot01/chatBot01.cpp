// dH 11/20/24
// chatBot01.cpp

/*
#include <iostream>
#include <string>
#include <curl/curl.h>
#include <nlohmann/json.hpp>

using json = nlohmann::json;
using namespace std;

// Callback function for cURL response
size_t WriteCallback02(void* contents, size_t size, size_t nmemb, string* out) {
    size_t totalSize = size * nmemb;
    out->append((char*)contents, totalSize);
    return totalSize;
}

// Function to send a message to OpenAI API
string sendMessageToChatbot02(const string& userMessage, const string& apiKey) {
    string responseString;
    CURL* curl = curl_easy_init();

    if (curl) {
        string url = "https://api.openai.com/v1/chat/completions";
        string payload = R"({
            "model": "gpt-3.5-turbo",
            "messages": [{"role": "user", "content": ")" + userMessage + R"("}]
        })";

        struct curl_slist* headers = nullptr;
        headers = curl_slist_append(headers, ("Authorization: Bearer " + apiKey).c_str());
        headers = curl_slist_append(headers, "Content-Type: application/json");

        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, payload.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseString);

        // Use a CA certificate bundle for SSL verification
        curl_easy_setopt(curl, CURLOPT_CAINFO, "C:/Users/BE129/cppStuff/chatBot01/cacert.pem");

        CURLcode res = curl_easy_perform(curl);
        if (res != CURLE_OK) {
            cerr << "cURL error: " << curl_easy_strerror(res) << endl;
        }

        curl_easy_cleanup(curl);
        curl_slist_free_all(headers);
    }

    if (responseString.empty()) {
        cerr << "Error: Empty response from API." << endl;
        return "";
    }

    return responseString;
}

int main02() {
    string apiKey = "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";
    string userMessage;
    string chatbotName = "Assistant";  // Default chatbot name
    string userName = "User";          // Default user name

    cout << "Chatbot (type 'exit' to quit):\n";

    while (true) {
        cout << "> ";
        getline(cin, userMessage);

        if (userMessage == "exit") break;

        // Send the user's query to the OpenAI API
        string response = sendMessageToChatbot02(userMessage, apiKey);

        // Parse and display the response
        try {
            json jsonResponse = json::parse(response);

            if (jsonResponse.contains("choices") && !jsonResponse["choices"].empty()) {
                if (jsonResponse["choices"][0]["message"].contains("content") &&
                    !jsonResponse["choices"][0]["message"]["content"].is_null()) {
                    string chatbotReply = jsonResponse["choices"][0]["message"]["content"];
                    cout << chatbotName << ": " << chatbotReply << "\n";
                } else {
                    cerr << chatbotName << ": Invalid or empty content in the API response." << endl;
                }
            } else if (jsonResponse.contains("error")) {
                cerr << chatbotName << ": API Error: " << jsonResponse["error"]["message"] << endl;
            } else {
                cerr << chatbotName << ": Unexpected API response structure." << endl;
            }
        } catch (const json::exception& e) {
            cerr << chatbotName << ": JSON parsing error: " << e.what() << "\n";
        }
    }

    return 0;
}
*/