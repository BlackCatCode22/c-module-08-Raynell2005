//
// Created by BE129 on 11/27/2024.
//

#include "crow_all.h" // Include the Crow header
#include <string>
#include <curl/curl.h>
#include <nlohmann/json.hpp>
#include <sstream>
#include <iomanip>
#include <deque>

using json = nlohmann::json;
using namespace std;

// Memory for chat history
deque<pair<string, string>> memory;
const size_t memoryLimit = 10;

// Function to escape JSON strings
string escapeJsonString(const string& input) {
    ostringstream escaped;
    for (char c : input) {
        switch (c) {
            case '"':  escaped << "\\\""; break;
            case '\\': escaped << "\\\\"; break;
            case '\b': escaped << "\\b"; break;
            case '\f': escaped << "\\f"; break;
            case '\n': escaped << "\\n"; break;
            case '\r': escaped << "\\r"; break;
            case '\t': escaped << "\\t"; break;
            default:
                if (c < 0x20 || c > 0x7E) {
                    escaped << "\\u" << hex << setw(4) << setfill('0') << (int)c;
                } else {
                    escaped << c;
                }
        }
    }
    return escaped.str();
}

// Function to construct payload
string constructPayload(const string& userMessage) {
    ostringstream payload;
    payload << "{\"model\": \"gpt-3.5-turbo\", \"messages\": [";

    for (const auto& [user, bot] : memory) {
        payload << "{\"role\": \"user\", \"content\": \"" << escapeJsonString(user) << "\"},";
        payload << "{\"role\": \"assistant\", \"content\": \"" << escapeJsonString(bot) << "\"},";
    }

    payload << "{\"role\": \"user\", \"content\": \"" << escapeJsonString(userMessage) << "\"}]}";
    return payload.str();
}

// Function to interact with OpenAI API
string sendMessageToChatbot(const string& userMessage, const string& apiKey) {
    string responseString;
    CURL* curl = curl_easy_init();

    if (curl) {
        string url = "https://api.openai.com/v1/chat/completions";
        string payload = constructPayload(userMessage);

        struct curl_slist* headers = nullptr;
        headers = curl_slist_append(headers, ("Authorization: Bearer " + apiKey).c_str());
        headers = curl_slist_append(headers, "Content-Type: application/json");

        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, payload.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, [](void* contents, size_t size, size_t nmemb, string* out) {
            size_t totalSize = size * nmemb;
            out->append((char*)contents, totalSize);
            return totalSize;
        });
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseString);
        curl_easy_setopt(curl, CURLOPT_CAINFO, "C:/Users/BE129/cppStuff/chatBot01/cacert.pem");

        CURLcode res = curl_easy_perform(curl);
        if (res != CURLE_OK) {
            cerr << "cURL error: " << curl_easy_strerror(res) << endl;
        }

        curl_easy_cleanup(curl);
        curl_slist_free_all(headers);
    }

    if (responseString.empty()) {
        cerr << "Error: Empty response from API." << endl;
        return "";
    }

    return responseString;
}

int main() {
    // Crow HTTP Server
    crow::SimpleApp app;

    string apiKey = "your-openai-api-key";

    // Endpoint for chatbot
    CROW_ROUTE(app, "/chat").methods("POST"_method)([&](const crow::request& req) {
        auto body = json::parse(req.body);
        string userMessage = body["message"];

        // Send user message to chatbot
        string chatbotResponse = sendMessageToChatbot(userMessage, apiKey);

        // Parse response and extract assistant's message
        try {
            json responseJson = json::parse(chatbotResponse);
            string assistantMessage = responseJson["choices"][0]["message"]["content"];

            // Add to memory
            memory.emplace_back(userMessage, assistantMessage);
            if (memory.size() > memoryLimit) memory.pop_front();

            // Return response
            json result;
            result["reply"] = assistantMessage;
            return crow::response(result.dump());
        } catch (const json::exception& e) {
            return crow::response(500, "Error parsing API response: " + string(e.what()));
        }
    });

    // Start the server
    cout << "Starting chatbot server at http://localhost:18080/chat" << endl;
    app.port(18080).multithreaded().run();
    return 0;
}

